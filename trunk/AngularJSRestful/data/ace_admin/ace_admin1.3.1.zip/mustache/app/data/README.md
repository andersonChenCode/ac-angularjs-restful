Please note that these data are only for demonstration purposes. So for ease of use I saved them as json/csv files.

A better way would be using databases to save your data and perhaps using MVC methods and frameworks for your application.
In that case you load your data within a controller and pass it onto the view.

You can also use a framework such as Zend, CI, Yii etc for PHP,
or Rails for Ruby and other ones for different languages,
and they all have bindings for Mustache if you like to use.
